package mooc.vandy.java4android.calculator.logic;

/**
 * Perform the Subtract operation.
 */
public class Subtract {
    // TODO -- start your code here
    private int operand1=0;
    private int operand2=0;

    public Subtract(int op1, int op2){ //constructor of the class

        operand1= op1;//assigns values to the local variables
        operand2= op2;
    }
    public String toString(){//returns string value after performing the desired operation on the operands received
        return String.valueOf(operand1-operand2);
    }
}