package mooc.vandy.java4android.calculator.logic;

import mooc.vandy.java4android.calculator.logic.Add;
import mooc.vandy.java4android.calculator.logic.Divide;
import mooc.vandy.java4android.calculator.logic.Multiply;
import mooc.vandy.java4android.calculator.logic.Subtract;
import mooc.vandy.java4android.calculator.ui.ActivityInterface;

/**
 * Performs an operation selected by the user.
 */
public class Logic 
       implements LogicInterface {
    /**
     * Reference to the Activity output.
     */
    protected ActivityInterface mOut;

    /**
     * Constructor initializes the field.
     */
    public Logic(ActivityInterface out){
        mOut = out;
    }

    /**
     * Perform the @a operation on @a argumentOne and @a argumentTwo.
     */
    public void process(int argumentOne,
                        int argumentTwo,
                        int operation){
        // TODO -- start your code here
        if (operation==1){
            Add addOp= new Add(argumentOne, argumentTwo); //creates an object of Add class
            mOut.print(addOp.toString());  // prints the result of the 'toString' method in the Add class
        }
        else if (operation==2){
            Subtract subtractOp= new Subtract(argumentOne, argumentTwo);//creates an object of Subtract class
            mOut.print(subtractOp.toString()); // prints the result of the 'toString' method in the Subtract class

        }
        else if (operation==3){
            Multiply multiplyOp = new Multiply(argumentOne,argumentTwo);//creates an object of Multiply class
            mOut.print(multiplyOp.toString()); // prints the result of the 'toString' method in the Multiply class
        }
        else if (operation==4){
            if (argumentTwo==0){
                mOut.print("Division by Zero");
            }
            else{
                Divide divideOp = new Divide(argumentOne,argumentTwo);//creates an object of Divide class
                mOut.print(divideOp.toString()); // prints the result of the 'toString' method in the Divide class
            }

        }

        }
    }
